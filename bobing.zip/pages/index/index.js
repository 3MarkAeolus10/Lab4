// pages/home/home.js
Page({
  player(audio) {
    var that = this
    audio.title = '你的答案'
    audio.src = 'https://mp32.9ku.com/upload/128/2019/11/08/998378.mp3'
    audio.onEnded(() => {
      that.player(wx.getBackgroundAudioManager())
    })
  },
  onLoad: function () {
    this.player(wx.getBackgroundAudioManager())
  },

  data: {
     
  },
  gotoSingle_game:function(){
    wx.navigateTo({
      url: '../single_game/single_game',
    })
  },
  gotoEntry:function(){
    wx.navigateTo({
      url: '../entry/entry',
    })
  },
  gotoRules:function(){
    wx.navigateTo({
      url: '../rules/rules',
    })
  },
})
