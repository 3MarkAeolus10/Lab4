App({
  globalData: {
    roomID:"",
    user_num:""
  },
  onLaunch: function () {
   
  },
  onShow: function(options) {

  },
  onHide: function() {
  
  },
        
  })