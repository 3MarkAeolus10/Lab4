// pages/home/home.js
Page({

  /**
   * Initial data of the page
   */
  data: {
     
  },
  gotoMulti1_game:function(){
    wx.navigateTo({
      url: '../multi1_game/multi1_game',
    })
  },
})
